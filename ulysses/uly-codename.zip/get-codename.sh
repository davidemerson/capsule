#!/bin/bash

ADJ=$(shuf -n 1 wordlist.adj)
NOUN=$(shuf -n 1 wordlist.noun)

echo "$ADJ $NOUN"